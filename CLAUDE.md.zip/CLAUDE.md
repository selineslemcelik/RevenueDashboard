# Revenue Dashboard

## Proje Özeti

Bu proje ASP.NET Core MVC (.NET 10) ile geliştirilen bir Revenue Dashboard uygulamasıdır.

Dashboard yöneticilerin gelir verilerini analiz edebilmesini sağlar.

Veriler şu anda Excel dosyalarından PostgreSQL veritabanına aktarılmaktadır.

İlerleyen aşamalarda veri kaynağı REST API'ye taşınabilecek şekilde katmanlı mimari kullanılmaktadır.

---

## Kullanılan Teknolojiler

- ASP.NET Core MVC
- .NET 10
- PostgreSQL
- Npgsql
- Bootstrap 5

---

## Mimari

Katman sırası her zaman:

Controller
→ Service
→ Repository
→ PostgreSQL

Bu sıra bozulmaz.

Controller doğrudan Repository çağırmaz.

Repository dışına SQL yazılmaz.

İş kuralları Service katmanında bulunur.

---

## Dependency Injection

Program.cs içerisinde:

- Repository sınıfları AddScoped
- Service sınıfları AddScoped
- IDbConnectionFactory AddSingleton

olarak kayıt edilir.

---

## Kod Standartları

- File-scoped namespace kullan.
- PascalCase isimlendirme kullan.
- private alanlar _camelCase şeklinde yazılır.
- Database işlemleri async olur.
- Para birimi decimal kullanır.
- SQL sorguları parametreli yazılır.

---

## Proje Amacı

Dashboard ekranında aşağıdaki bilgiler gösterilecektir:

- Toplam gelir
- Kanal bazlı gelirler
- Şirket bazlı gelirler
- Tarih bazlı analiz
- Grafikler
- Filtreleme
- Özet kartları (Summary Cards)

Amaç büyük veri kümelerini yöneticilerin kolay analiz edebilmesini sağlamaktır.

---

## Claude'dan Beklenenler

Kod yazarken:

- Mevcut katmanlı mimariyi bozma.
- Gereksiz dosya oluşturma.
- Aynı isimde farklı DTO üretme.
- Repository dışında SQL yazma.
- Async yapıyı koru.
- Mevcut kod stiline sadık kal.
- Yeni özellik eklerken önce mevcut yapıyı incele.
- Değiştirilen dosyaları işlem sonunda özetle.

## Sık Karşılaşılan Hatalar

### CS1061
DashboardViewModel'de property bulunamadığında önce:
- DashboardViewModel
- DashboardController
- Index.cshtml

dosyalarını karşılaştır.

---

### CS1501
Method parametresi değiştiyse şu zinciri kontrol et:

Controller
↓
Service
↓
Repository
↓
Interface

---

### Yeni metot eklenirse

Yeni metot eklendiğinde aşağıdaki dosyaların tamamı güncellenmelidir.

- IRevenueRepository
- RevenueRepository
- IDashboardService
- DashboardService
- DashboardController
- DashboardViewModel (gerekiyorsa)
- Razor View

---

### Build hatalarında izlenecek sıra

1. İlk build hatasını çöz.
2. Interface ve implementasyonları karşılaştır.
3. Controller → Service → Repository zincirini kontrol et.
4. Razor View'da silinmiş property kullanılıyor mu kontrol et.
5. Program.cs içindeki Dependency Injection kayıtlarını doğrula.

---

### UI Kuralları

Bu proje artık filtre kullanılan bir dashboard değildir.

TV ekranında sürekli açık duran yönetici dashboard'ı hedeflenmektedir.

Kartlar aynı hizada olmalıdır.

Grafikler tek ekranda mümkün olduğunca görünmelidir.

Boşluklar minimum tutulmalıdır.

Grafikler ve tablolar okunabilir olmalıdır.